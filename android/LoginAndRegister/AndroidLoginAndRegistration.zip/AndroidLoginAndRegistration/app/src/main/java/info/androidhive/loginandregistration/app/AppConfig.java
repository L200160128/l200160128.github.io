package info.androidhive.loginandregistration.app;

public class AppConfig {
	// Server user login url
	public static String URL_LOGIN = "https://bana.web.id/android_login_api/login.php";

	// Server user register url
	public static String URL_REGISTER = "https://bana.web.id/android_login_api/register.php";
}
